﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ICDB.Models
{
    public class AddMovie
    {
        public int MovieID { get; set; }
        public string MovieName { get; set; }
        public string Plot { get; set; }
        public byte[] Poster { get; set; }
        public string PosterPath { get; set; }
        public string VideoURL {get;set;}
        public int ReleaseDate { get; set; }
        public int ActorID { get; set; }
        public string ActorName { get; set; }
        public int DirectorID { get; set; }
        public string DirectorName { get; set; }
        public int MusicDirectorID { get; set; }
        public string MusicDirectorName { get; set; }
        public int ProducerID { get; set; }
        public string ProducerName { get; set; }
        public IEnumerable<Actor> iActors { get; set; }
        public IEnumerable<Director> iDirectors { get; set; }
        public IEnumerable<MusicDirector> iMusicDirectors { get; set; }
        public IEnumerable<Producer> iProducers { get; set; }

    }
    public class Actor
    {
        public int ActorID { get; set; }
        public string ActorName { get; set; }
    }
    public class Director
    {
        public int DirectorID { get; set; }
        public string DirectorName { get; set; }
    }
    public class MusicDirector
    {
        public int MusicDirectorID { get; set; }
        public string MusicDirectorName { get; set; }
    }
    public class Producer
    {
        public int ProducerID { get; set; }
        public string ProducerName { get; set; }
    }
}