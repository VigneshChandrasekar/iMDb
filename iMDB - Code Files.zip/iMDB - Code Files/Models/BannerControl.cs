﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ICDB.Models
{
    public class BannerControl
    {
        public int MovieID_1 { get; set; }
        public string Name_1 { get; set; }
        public string Plot_1 { get; set; }
        public int MovieID_2 { get; set; }
        public string Name_2 { get; set; }
        public string Plot_2 { get; set; }
        public int MovieID_3 { get; set; }
        public string Name_3 { get; set; }
        public string Plot_3 { get; set; }
        public int MovieID_4 { get; set; }
        public string Name_4 { get; set; }
        public string Plot_4 { get; set; }
    }
}